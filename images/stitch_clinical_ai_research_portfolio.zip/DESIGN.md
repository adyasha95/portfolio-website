---
name: Clinical Intelligence Narrative
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#c2c6d5'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#8c909f'
  outline-variant: '#424753'
  surface-tint: '#adc6ff'
  primary: '#adc6ff'
  on-primary: '#002e69'
  primary-container: '#4d8efe'
  on-primary-container: '#00285c'
  inverse-primary: '#005ac1'
  secondary: '#4fdbc8'
  on-secondary: '#003731'
  secondary-container: '#04b4a2'
  on-secondary-container: '#003f38'
  tertiary: '#c6c6c7'
  on-tertiary: '#2f3131'
  tertiary-container: '#909191'
  on-tertiary-container: '#282a2a'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a41'
  on-primary-fixed-variant: '#004494'
  secondary-fixed: '#71f8e4'
  secondary-fixed-dim: '#4fdbc8'
  on-secondary-fixed: '#00201c'
  on-secondary-fixed-variant: '#005048'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c7'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#454747'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  display-xl:
    fontFamily: Space Grotesk
    fontSize: 72px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.7'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1.0'
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-page: 64px
  section-gap: 128px
---

## Brand & Style

This design system is engineered for a PhD-level Clinical AI Researcher, merging the rigorous professionalism of medical science with the high-velocity innovation of artificial intelligence. The aesthetic is heavily inspired by DeepMind’s corporate identity: dark, sophisticated, and intellectually authoritative.

The style is a hybrid of **Minimalism** and **Glassmorphism**. It utilizes a "Deep Black" canvas to allow high-fidelity data visualizations and "Electric Blue" accents to pop, signifying energy and precision. The emotional response is one of "Technical Prestige"—it should feel like entering a high-end research laboratory or a secure data environment. Visual interest is maintained through subtle "circuitry" patterns and microscopic data grids that reinforce the subject matter expertise.

## Colors

The palette is anchored in a high-contrast dark mode to reduce eye strain during deep reading while maintaining a premium feel.

- **Primary (Electric Blue):** Used for critical actions, active states, and highlighting key research findings. It represents the "AI" component of the brand.
- **Secondary (Teal):** Used for accents, data visualization gradients, and subtle success indicators. It bridges the gap between technology and biology.
- **Backgrounds:** The foundation is a pure Deep Black (#0A0A0A), with secondary surfaces using a slightly lighter Charcoal (#171717) to create perceived depth.
- **Typography:** Pure White is reserved for headings to ensure maximum impact, while high-contrast grays are used for body text to improve legibility.

## Typography

The typography strategy emphasizes clarity and technical authority. **Space Grotesk** is chosen for headlines for its geometric, futuristic qualities that evoke a sense of innovation and scientific discovery. It should be used at large scales with tight letter spacing for a bold, editorial look.

**Inter** serves as the workhorse for body content and data labels. It provides a clean, neutral, and utilitarian feel essential for presenting complex clinical research papers and methodologies. Line heights are kept generous (1.6x - 1.7x) to ensure that dense academic text remains accessible and readable.

## Layout & Spacing

The system follows a **Fixed Grid** approach for desktop views to maintain a controlled, prestigious layout, while transitioning to a fluid model for mobile. A 12-column grid is standard, with generous margins to create "white space" (negative space) that allows the content to breathe.

Spacing follows an 8px linear scale. Large gaps (128px+) between major sections are encouraged to differentiate between various research projects, publications, and career milestones. Content should be centered with significant horizontal padding to focus the user’s eye on the narrative.

## Elevation & Depth

Hierarchy is established through **Glassmorphism** and **Tonal Layering** rather than traditional shadows.

1.  **Base Layer:** The deepest black (#0A0A0A) background.
2.  **Middle Layer:** Card surfaces using #171717 with a very subtle 1px border (#FFFFFF, 10% opacity) to define edges.
3.  **Top Layer (Glass):** Interactive overlays and modals use a backdrop-blur (minimum 12px) with a semi-transparent dark fill.
4.  **Glows:** High-fidelity "Radial Glows" in Electric Blue and Teal are placed behind key components to create a sense of light emanating from the data. These glows should be soft, large, and low-opacity (5-10%).

## Shapes

The design system uses a **Soft** shape language. Sharp corners are avoided to prevent the UI from feeling overly "aggressive" or "brutalist," but high roundedness (pills) is avoided to maintain a professional, clinical aesthetic. 

Small components (buttons, chips) use 0.25rem (4px) radii. Larger containers like research cards use 0.5rem (8px). This creates a subtle precision that mimics modern medical hardware and software interfaces.

## Components

- **Primary Buttons:** Solid Electric Blue with white text. On hover, a subtle cyan outer glow expands.
- **Glass Cards:** Used for research projects. Features a 1px top-border highlight and a background blur. The card should feel like a piece of glass floating above a data grid.
- **Status Chips:** Small, uppercase labels used to categorize research areas (e.g., "NLP," "ONCOLOGY"). These use a semi-transparent Teal background with high-contrast text.
- **Input Fields:** Minimalist design—bottom border only or a very subtle outlined container. Focus state triggers a glowing blue bottom-border.
- **Data Grids:** Subtle, non-intrusive grid lines (1px width, 5% opacity) that act as a background texture for sections containing quantitative data.
- **Research Timeline:** A vertical line element in a blue-to-teal gradient, used to visualize career progression and publication dates.